<!DOCTYPE html>
<html lang="es">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
        <meta charset="UTF-8">
        <title>Wine Juggler - Panel</title>
        <meta name="author" content="https://t.me/neo_net" />
        <link rel="shortcut icon" type="image/png"  href="./favicon.png"/>
        <!-- Styles -->
        <link type="text/css" rel="stylesheet" href="css/material.css"/>
        <link type="text/css" rel="stylesheet" href="css/login.css"/>
        <link href="css/alpha.min.css" rel="stylesheet" type="text/css"/>
    </head>
    <body class="signin-page">
<?php
if (isset($_POST['btn-login'])) {
include 'php/database/db.php';}
include 'php/login/checker.php';
$_SESSION['LAST_CALL'] = date("Y-m-d h:i:s");
?>
        <div class="mn-content valign-wrapper">
            <main class="mn-inner container">
                <div class="valign">
                      <div class="row">
                          <div class="col s12 m6 l4 offset-l4 offset-m3">
            <?php if (@$_GET['rel'] === 'exit'): ?>
            <div class="card blue">
            <div class="card-content white-text">
            <p>Se ha cerrado tu sesión correctamente. </p>
            </div>
            </div>
            <?php endif; ?>

            <?php if (@$_GET['rel'] === 'error'): ?>
            <div class="card red">
            <div class="card-content white-text">
            <p>Nombre de Usuario o Contraseña Invalidos.</p>
            </div>
            </div>
            <?php endif; ?>
<div class="card white darken-1">
<div class="card-content">
<img src="./images/logo.png" class="logo-active">
<span class="card-title-custom">Panel 2.0 - Wine Juggler</span><br>
<div class="row custom-row">
<form method="post" id="login-form" class="col s12">
<div class="input-field col s12">
<input id="us" type="text" name="us" class="validate" autocomplete="off" data-msg="Usuario Requerido" placeholder="Ex : Admin">
<label for="us">Email o Usuario</label>
</div>
<div class="input-field col s12">
<input id="pw" type="password" name="pw" class="validate" autocomplete="off" data-msg="Contraseña Requerida" placeholder="Ex : ******">
<label for="pw">Contraseña</label>
</div>
<div class="col s12 center-align m-t-sm">
<button class="g-recaptcha waves-effect waves-light btn teal no-shadow" name="btn-login" id="btn-login" type="submit">Iniciar Sesión</button>
</div></form></div></div></div></div></div></div></main></div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/jquery.validate.min.js"></script>
<script type="text/javascript" src="js/additional-methods.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
$('.blue').delay(2500).fadeOut('slow');
$('.red').delay(2500).fadeOut('slow');});
  $("#login-form").validate({
        rules: {
            us: {required: true},
            pw: {required: true},
        errorElement : 'div',
        errorPlacement: function(error, element) {
          var placement = $(element).data('error');
          if (placement) {$(placement).append(error)} else {error.insertAfter(element);}}}});
</script>
</body>
</html>