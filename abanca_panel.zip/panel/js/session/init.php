<?php
session_start();
include '../../php/database/db.php';
$hash = @$_COOKIE['identificator'];
if (!isset($hash)) {
echo 'logout?cast=message&logout&identificator='.@$_COOKIE['identificator'].'';
}
if (!isset($_SESSION['userSession'])) {
echo 'logout?cast=message&logout&identificator='.@$_COOKIE['identificator'].'';
}

?>