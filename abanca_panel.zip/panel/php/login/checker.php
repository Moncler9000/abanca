<?php
session_start();
if (isset($_SESSION['userSession'])!=""){
header("Location: /index?calendar=events");
exit;}
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
*/
/* Check button "login" Pressed and send the data*/
function usermanhrg($length = 25) {
$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$charactersLength = strlen($characters);
$randomString = '';
for ($i = 0; $i < $length; $i++) {
$randomString .= $characters[rand(0, $charactersLength - 1)];
}return $randomString;}
	function getIPAddress(){
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		$ip = $_SERVER['HTTP_CLIENT_IP'];
		}
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		 $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else{
		  $ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}
$kip = getIPAddress();
if (isset($_POST['btn-login']) && isset($_SESSION['LAST_CALL'])) {
    $last = strtotime($_SESSION['LAST_CALL']);
    $curr = strtotime(date("Y-m-d h:i:s"));
    $sec =  abs($last - $curr);
    if ($sec <= 1) {
    /*
BOT
    */
    }
    else {
$email = strip_tags($_POST['us']);
$password = strip_tags($_POST['pw']);
$email = $connection->real_escape_string($email);
$password = $connection->real_escape_string($password);
$query = $connection->query("SELECT user_id, username, password FROM tbl_users WHERE username='$email' or email='$email'");
$row=$query->fetch_array();
$count = $query->num_rows;
/* If email/password are correct returns must be 1 row and pass to the index */
if (password_verify($password, $row['password']) && $count==1) {
$rel = $row['user_id'];
$realbossxx = "DELETE from secure where username=".$rel."";
$connection->query($realbossxx);
$sex = usermanhrg();
$realboss = "INSERT INTO secure(username,hash) VALUES('$rel','$sex')";
$connection->query($realboss);
$_SESSION['userSession'] = $row['user_id'];
session_cache_expire(12000);
setcookie("identificator", $sex, 2147483647, '/');
header("Location: ./index.php?calendar=events");
}else {header("Location: ./login.php?rel=error");}
}}