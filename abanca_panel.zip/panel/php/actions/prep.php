<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php que nos actualiza usuarios
*/
session_start();
include '../database/db.php';

$token = 'c2b383a312fc80d0cee942ad01a63aa4';
if (@$_POST['token'] == $token) {
$id = $connection->real_escape_string(@$_POST['numero']);
$update = $connection->query("UPDATE numeros set status=0 where numero='$id'");
}