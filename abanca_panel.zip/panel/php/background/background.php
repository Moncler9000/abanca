<?php
include 'bing.php';
include '../database/db.php';
include '../gravatar/get.php';


/* Load the bing Background Api and shows new background every day */
$bing  = new BingPhoto(BingPhoto::YESTERDAY, 1, 'es-MX', BingPhoto::RESOLUTION_HIGH);
foreach ($bing->getImages() as $image) {
$ch = curl_init($image['url']);
$fp = fopen('../../images/background.jpg', 'w');
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_exec($ch);
curl_close($ch);
fclose($fp);

}


$rpm = $connection->query("SELECT * FROM tbl_users");
while($row = mysqli_fetch_assoc($rpm)):
$owbourne = get_gravatar(''.$row['email'].'');
$image['url'] = $owbourne;
$ch = curl_init($image['url']);
$fp = fopen('../../images/profile/'.$row['email'].'.jpg', 'w');
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_exec($ch);
curl_close($ch);
fclose($fp);
endwhile;
$querx = $connection->query("TRUNCATE TABLE secure");
//Maintenance Crons
$okl = $connection->query("UPDATE clientes SET nombre = REPLACE(nombre, '  ',' ')");
$okl = $connection->query("UPDATE ventas  set caja = trim(caja)");
$okls = $connection->query("UPDATE clientes SET nombre = LOWER(nombre)");
echo 'Cronjob Complete';
?>