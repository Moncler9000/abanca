<!DOCTYPE html>
<html lang="es">
    <head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
<meta charset="UTF-8">
<title>Dashboard</title>
        <link rel="shortcut icon" type="image/png"  href="./favicon.png"/>
<!--Import materialize.css-->
<link type="text/css" rel="stylesheet" href="css/material.css"/>
<link href="css/custom.css" rel="stylesheet" />
<link rel="stylesheet" href="css/jquery-ui.css" />
<link rel="stylesheet" href="css/sweetalert2.min.css">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="js/sweetalert2.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/datatables.min.css"/>
<script type="text/javascript" src="js/datatables.js"></script>
<script src="https://cdn.jsdelivr.net/clipboard.js/1.5.3/clipboard.min.js"></script>
    </head>
    <body>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include 'php/gravatar/get.php';
include 'php/database/db.php';
include 'php/login/true.php';
?>
  <!-- Start Header -->
  <div class="navbar-fixed">
    <nav class="cyan darken-1"><p class="estadistica numero-firmas hide">0</p><p class="estadistica numero-status hide">0</p>
        <a href="#" class="brand-logo"><img class="imagi" src="./images/logo2.png"></a>
        <ul class="right hide-on-med-and-down">
          <?php if ($userRow['rango'] === 'root'): ?>
        <?php endif; ?>
          <li><a class="dropdown-trigger btn custom-profile" href="#" data-target="dropdown1"><?php echo htmlentities($userRow['username']);?></a></li>
        <ul id="dropdown1" class="dropdown-content">
          <li><a href="./logout.php?rel=<?php echo @$_COOKIE['identificator']; ?>"><i class="material-icons">keyboard_tab</i>Salir</a></li>
      </ul>
        </ul>
  <ul id="slide-out" class="sidenav">
<ul id="slide-out" class="side-nav" style="transform: translateX(0px);">
<img src="./images/logo.png" class="logo-active">
<div class="divider"></div>
<?php if ($userRow['rango'] === 'root'): ?>
 <div class="divider"></div>
<?php endif; ?>
<li><a class="subheader">Opciones de Usuario</a></li>
<li class="no-padding">
<ul class="collapsible collapsible-accordion">
<li>
<a class="collapsible-header"><?php echo htmlentities($userRow['username']); ?></a>
<div class="collapsible-body">
<ul>
<li><a href="./logout.php?rel=<?php echo @$_COOKIE['identificator']; ?>"><i class="material-icons">keyboard_tab</i>Salir</a></li>
</ul>
</div>
</li>
</ul>
</li>
</ul>
<ul class="right hide-on-med-and-down">
<ul id="dropdown1" class="dropdown-content">
<li><a href="./logout.php?rel=<?php echo @$_COOKIE['identificator']; ?>"><i class="material-icons">keyboard_tab</i>Salir</a></li>
</ul></li>
</ul>
  </ul>
  <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
    </nav>
  </div>
<!-- End header -->
<!-- Preloader -->
   <div class="l-loader">
    <div class="text">
        <span class="letter">D</span><span class="letter">A</span><span class="letter">S</span><span class="letter">H</span><span class="letter">B</span><span class="letter">O</span><span class="letter">A</span><span class="letter">R</span><span class="letter">D</span><span class="letter pulse"></span>
    </div>
</div>
  <!-- Modal Structure -->
  <div id="modal-comment" class="modal modal-fixed-footer">
    <div class="modal-content">
      <h4>Añadir Comentarios</h4><br>
    <div class="input-field col s6">
      <input id="comentario" type="text" class="validate">
      <input value="ID" id="id_oculto" type="hidden" class="validate">
      <label class="active" for="comentario">Comentarios</label>
  </div>
    </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Cerrar</a>
      <a href="#!" class="waves-effect waves-green btn-flat comentar blue lighten-1 text-white">Añadir</a>

    </div>
  </div></div>



  <!-- Modal Structure -->
  <div id="modal-logodatos" class="modal modal-fixed-footer">
    <div class="modal-content">
      <h4>Log Data</h4><br>
    <div class="input-field col s6 logo-datos">
    </div>
  </div>
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Cerrar</a>

    </div></div>
<!-- End Preloader -->
<div class="hide session-crypt"></div>
<!-- Start Content -->
<div class="row">
    <div class="col s12 m12 maincrypt"><br>
      <h4>Logs</h4>
</h4>
<div class="container-notifications"></div>
</div></div><br><br><br>
<!-- End Content -->
<!--Import materialize.js-->
<script type="text/javascript" src="js/panel.js"></script>
<script type="text/javascript">  M.AutoInit();</script>
</body>
</html>