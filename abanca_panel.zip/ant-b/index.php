<?php
/**
###############################################
#$      https://telegram.me/neo_net          $#
#$          The Wine Juggler of FUD          $#
###############################################
**/
header("HTTP/1.0 404 Not Found");
exit();
?>
